create view empview as
select `test`.`employee`.`employeeNO`   AS `employeeNO`,
       `test`.`employee`.`employeeName` AS `employeeName`,
       `test`.`employee`.`sex`          AS `sex`,
       `test`.`employee`.`birthday`     AS `birthday`,
       `test`.`employee`.`address`      AS `address`,
       `test`.`employee`.`telephone`    AS `telephone`,
       `test`.`employee`.`department`   AS `department`,
       `test`.`employee`.`headShip`     AS `headShip`,
       `test`.`employee`.`salary`       AS `salary`
from `test`.`employee`;

grant select on table empview to 吴嘉炜@localhost;

