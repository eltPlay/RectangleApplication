create view emp_view as
select `test`.`employee`.`employeeNO`   AS `employeeNo`,
       `test`.`employee`.`employeeName` AS `employeeName`,
       `test`.`employee`.`sex`          AS `sex`,
       `test`.`employee`.`salary`       AS `salary`
from `test`.`employee`;

